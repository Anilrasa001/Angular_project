import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  @Input() username: string = '';
  @Input() email: string = '';
  
  @Output() usernameChange = new EventEmitter<string>();
  @Output() emailChange = new EventEmitter<string>();

  onUsernameChange(value: string) {
    this.username = value;
    this.usernameChange.emit(value);
  }

  onEmailChange(value: string) {
    this.email = value;
    this.emailChange.emit(value);
  }
}