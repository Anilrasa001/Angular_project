import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RegisterComponent } from '../register/register.component';

@Component({
  selector: 'app-parent',
  standalone: true,
  imports: [CommonModule, FormsModule, RegisterComponent],
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent {
  username: string = '';
  email: string = '';
  validationMessage: string = '';
  isValid: boolean | null = null;

  validateRegistration(): void {
    const isUsernameValid = this.username.length >= 5;
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.email);

    if (isUsernameValid && isEmailValid) {
      this.validationMessage = 'Registered Successfully';
      this.isValid = true;
    } else {
      this.validationMessage = 'X Invalid Details';
      this.isValid = false;
    }
  }
}