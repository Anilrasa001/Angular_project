import { Component, OnInit } from '@angular/core';
import { IProduct } from '../models/iproduct';
import { ProductService } from '../product.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product',
  imports: [CommonModule],
  providers:[ProductService],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent implements OnInit{
  products: IProduct[] = [];

  constructor(private productService: ProductService) {}

  ngOnInit(): void {

    this.productService.getProducts().subscribe(data => {
      this.products = data;
    });

   
  }

}
