import { Component } from '@angular/core';

@Component({
  selector: 'app-productdetails',
  imports: [],
  templateUrl: './productdetails.component.html',
  styleUrls:[ './productdetails.component.css']
})
export class ProductdetailsComponent {
  product ={
    id:101,
    name:'TV',
    price:30000,
    description:'HD Quality',
    image:'../iamges/img2.jpg'
  }

}