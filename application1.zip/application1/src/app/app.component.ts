import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ProductdetailsComponent } from './productdetails/productdetails.component';
import { CommonModule } from '@angular/common';
import { ProductComponent } from './product/product.component';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,ProductComponent,CommonModule,ProductdetailsComponent,HttpClientModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'application1';
}
