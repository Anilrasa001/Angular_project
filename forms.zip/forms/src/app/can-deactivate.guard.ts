import { CanDeactivateFn } from '@angular/router';
import { ContactformComponent } from './contactform/contactform.component';


export const canDeactivateGuard: CanDeactivateFn<ContactformComponent> = (component) => {
  return component.isFormDirty()
    ? confirm('You have unsaved changes. Are you sure you want to leave?')
    : true;
};